package com.kitri.cnm.movie;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;

@Component("movService")
public class MovieServiceImpl implements MovieService {
	@Resource(name = "sqlSession")
	private SqlSession sqlSession;
	private MovieMapper movieMapper;

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public void insertMyMovie(MovieVO movie) {
		movieMapper = sqlSession.getMapper(MovieMapper.class);
		movieMapper.insertMyMovie(movie);
	}

	@Override
	public void updatetMyMovie(MovieVO movie) {
		movieMapper = sqlSession.getMapper(MovieMapper.class);
		movieMapper.updateMyMovie(movie);
	}

	@Override
	public int checkList(MovieVO movie) {
		movieMapper = sqlSession.getMapper(MovieMapper.class);
		Integer num = movieMapper.checkList(movie);
		if (num != null) {
			return num;
		} else {
			return 0;
		}
	}

	@Override
	public List<String> getMembers(String id) {
		movieMapper = sqlSession.getMapper(MovieMapper.class);
		return movieMapper.getMembers(id);
	}

	@Override
	public List<MovieVO> getList(String id) {
		movieMapper = sqlSession.getMapper(MovieMapper.class);
		return movieMapper.getList(id);
	}

	@Override
	public void updateRating(MovieVO m) {
		movieMapper = sqlSession.getMapper(MovieMapper.class);
		movieMapper.updaterate(m);
	}

	@Override
	public void delMyMovie(int seq) {
		movieMapper = sqlSession.getMapper(MovieMapper.class);
		movieMapper.delmovie(seq);
	}
}
