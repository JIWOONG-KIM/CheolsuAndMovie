package com.kitri.cnm.soc;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;

@Component("socService")
public class SocServiceImpl implements SocService {
	@Resource(name = "sqlSession")
	private SqlSession sqlSession;
	private SocMapper socMapper;
	
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public void writeletter(SocVO sv) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		System.out.println(sv);
		socMapper.insertletter(sv);
	}

	@Override
	public List<SocVO> findletter(HashMap<String, Object> map) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.selectletter(map);
	}

	@Override
	public void removeletter(int letter_seq) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		socMapper.deleteletter(letter_seq);
	}

	@Override
	public SocVO getletter(int letter_seq) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.getfindLetter(letter_seq);
	}

	@Override
	public void readletter(int letter_seq) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		socMapper.updateletter(letter_seq);
	}

	@Override
	public void readdate(int letter_seq) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		socMapper.updatedate(letter_seq);
	}

	@Override
	public String findrcvid(int letter_seq) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.selectrcvid(letter_seq);
	}

	@Override
	public List<SocVO> getrcvlet(HashMap<String, Object> map) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.myrcvletter(map);
	}

	@Override
	public List<SocVO> getsendlet(HashMap<String, Object> map) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.mysendletter(map);
	}

	@Override
	public List<SocVO> getdontread(HashMap<String, Object> map) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.mydontread(map);
	}

	@Override
	public int listcnt(String user_id) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.listcnt(user_id);
	}

	@Override
	public int listcnt2(String user_id) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.listcnt2(user_id);
	}

	@Override
	public String rcvletid(String user_id) {
		socMapper = sqlSession.getMapper(SocMapper.class);
		return socMapper.srchid(user_id);
	}
	
	
}
