package com.kitri.cnm.soc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SocController {
	@Resource(name = "socService")
	private SocService socservice;

	public void setSocService(SocService socservice) {
		this.socservice = socservice;
	}

	@RequestMapping(value = "/letter/letterhome.do")
	public ModelAndView letterhome(HttpServletRequest req, int currentPage) {
		HttpSession session = req.getSession(false);
		String user_id = (String) session.getAttribute("id");
		ModelAndView homeview = new ModelAndView();
		List<SocVO> letlist = new ArrayList<SocVO>();
		PageVO page = new PageVO();
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("user_id", user_id);
		map.put("currentPage", currentPage);
		letlist = socservice.findletter(map);	
		int totalCount = socservice.listcnt(user_id);
		int cntPerPage=5;
		int totalPage=(int)Math.ceil((double)totalCount/ cntPerPage);
		int cntPerPageGroup=5;
		int startPage=((int)(currentPage-1)/cntPerPageGroup)*cntPerPageGroup+1;
		int endPage=startPage+cntPerPageGroup-1;
		if(endPage>totalPage) {
			endPage=totalPage;
		}
		page.setCurrentPage(currentPage);
		page.setTotalPage(totalPage);
		page.setList(letlist);
		page.setStartPage(startPage);
		page.setEndPage(endPage);
		homeview.setViewName("letter/letterhome");
		homeview.addObject("page",page);
		return homeview;
	}

	@RequestMapping(value="/letter/lettermyrcv.do")
	public ModelAndView lettermyrcv(HttpServletRequest req, @RequestParam(value="rcv_id")String user_id, int currentPage) {
		ModelAndView rcvletmv = new ModelAndView();
		List<SocVO> letlist = new ArrayList<SocVO>();
		PageVO page = new PageVO();
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("user_id", user_id);
		map.put("currentPage", currentPage);
		letlist = socservice.getrcvlet(map);
		int totalCount = socservice.listcnt(user_id);
		int cntPerPage=5;
		int totalPage=(int)Math.ceil((double)totalCount/ cntPerPage);
		int cntPerPageGroup=5;
		int startPage=((int)(currentPage-1)/cntPerPageGroup)*cntPerPageGroup+1;
		int endPage=startPage+cntPerPageGroup-1;
		if(endPage>totalPage) {
			endPage=totalPage;
		}
		page.setCurrentPage(currentPage);
		page.setTotalPage(totalPage);
		page.setList(letlist);
		page.setStartPage(startPage);
		page.setEndPage(endPage);
		rcvletmv.setViewName("letter/letterhome3");
		rcvletmv.addObject("page",page);
		return rcvletmv;
	}
	
	@RequestMapping(value="/letter/lettermysend.do")
	public ModelAndView lettermysend(@RequestParam(value="user_id") String user_id, int currentPage) {
		ModelAndView sendletmv = new ModelAndView();
		List<SocVO> letlist = new ArrayList<SocVO>();
		PageVO page = new PageVO();
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("user_id", user_id);
		map.put("currentPage", currentPage);
		letlist = socservice.getsendlet(map);
		int totalCount = socservice.listcnt2(user_id);
		int cntPerPage=5;
		int totalPage=(int)Math.ceil((double)totalCount/ cntPerPage);
		int cntPerPageGroup=5;
		int startPage=((int)(currentPage-1)/cntPerPageGroup)*cntPerPageGroup+1;
		int endPage=startPage+cntPerPageGroup-1;
		if(endPage>totalPage) {
			endPage=totalPage;
		}
		page.setCurrentPage(currentPage);
		page.setTotalPage(totalPage);
		page.setList(letlist);
		page.setStartPage(startPage);
		page.setEndPage(endPage);
		sendletmv.setViewName("letter/letterhome2");
		sendletmv.addObject("page",page);
		return sendletmv;
	}
	
	@RequestMapping(value="/letter/letdontread.do")
	public ModelAndView dontletread(HttpServletRequest req, @RequestParam(value="rcv_id")String user_id, int currentPage){
		System.out.println("currentPage="+currentPage);
		if(currentPage==0) {
			currentPage=1;
		}
		System.out.println("letdontread");
		ModelAndView dontreadmv = new ModelAndView();
		List<SocVO> letlist = new ArrayList<SocVO>();
		HashMap<String, Object> map = new HashMap<String, Object>();
		PageVO page = new PageVO();
		map.put("user_id", user_id);
		map.put("currentPage", currentPage);
		letlist = socservice.getdontread(map);
		int totalCount = socservice.listcnt(user_id);
		int cntPerPage=5;
		int totalPage=(int)Math.ceil((double)totalCount/ cntPerPage);
		int cntPerPageGroup=5;
		int startPage=((int)(currentPage-1)/cntPerPageGroup)*cntPerPageGroup+1;
		int endPage=startPage+cntPerPageGroup-1;
		if(endPage>totalPage) {
			endPage=totalPage;
		}
		page.setCurrentPage(currentPage);
		page.setTotalPage(totalPage);
		page.setList(letlist);
		page.setStartPage(startPage);
		page.setEndPage(endPage);
		System.out.println("page="+page);
		dontreadmv.setViewName("letter/letterhome");
		dontreadmv.addObject("page",page);
		return dontreadmv;
	}
	
	@RequestMapping(value = "/letter/letteraside.do")
	public String letteraside() {
		return "letter/letteraside";
	}

	@RequestMapping(value = "/letter/letterwrite.do")
	public ModelAndView letterwrite(HttpServletRequest req, String letter_seq) {
		ModelAndView wrletter = new ModelAndView();
		if (letter_seq != null) {
			wrletter.addObject("letrcvid", socservice.findrcvid(Integer.parseInt(letter_seq)));
		}
		wrletter.setViewName("letter/letterwrite");

		return wrletter;
	}

	@RequestMapping(value = "/letter/sendletter.do")
	public ModelAndView sendForm(HttpServletRequest req, SocVO sv) {
		ModelAndView sendletter = new ModelAndView();
		int currentPage=1;
		String[] real_rcv_id = sv.getRcv_id().split(",");
		int check=0;
		for (int i = 0; i < real_rcv_id.length; i++) {
			System.out.println(":::::"+real_rcv_id[i]);
			if(socservice.rcvletid(real_rcv_id[i])==null) {
				System.out.println("입력값이 잘못되었습니다.");
				check=1;
			}
		}
		if(check==0){
			for (int i = 0; i < real_rcv_id.length; i++) {
				sv.setRcv_id(real_rcv_id[i]);
				socservice.writeletter(sv);
			}
		}
		sendletter.addObject("currentPage", currentPage);
		sendletter.setViewName("redirect:letterhome.do");
		return sendletter;
	}

	@RequestMapping(value = "/letter/deleteletter.do")
	public ModelAndView removeForm(HttpServletRequest req,
			@RequestParam(value = "letter_seq") List<Integer> letter_seq) {
		HttpSession session = req.getSession(false);
		String user_id = (String) session.getAttribute("id");
		ModelAndView removeletter = new ModelAndView();
		for (int i = 0; i < letter_seq.size(); i++) {
			socservice.removeletter(letter_seq.get(i));
		}
		System.out.println("받는사람아이디"+socservice.rcvletid(user_id));
		if(user_id.equals(socservice.rcvletid(user_id))) {
			removeletter.setViewName("redirect:lettermysend.do?currentPage=1&&user_id="+user_id);
		}else {
			removeletter.setViewName("redirect:letterhome.do?currentPage=1");
		}
		return removeletter;
	}

	@RequestMapping(value = "/letter/letterresult.do")
	public ModelAndView resultForm(HttpServletRequest req, HttpSession session,
			@RequestParam(value = "letter_seq") int letter_seq) {
		ModelAndView resultlet = new ModelAndView();
		SocVO letsv = new SocVO();
		letsv = socservice.getletter(letter_seq);
		socservice.readletter(letter_seq);
		socservice.readdate(letter_seq);
		resultlet.addObject("letsv", letsv);
		resultlet.setViewName("letter/letterresult");
		return resultlet;
	}

	/*
	 * @RequestMapping(value="/letter/letterreturn.do") public ModelAndView
	 * returnForm(HttpServletRequest req, HttpSession
	 * session, @RequestParam(value="letter_seq") int letter_seq) { ModelAndView
	 * returnlet = new ModelAndView(); SocVO retsv = new SocVO(); retsv =
	 * socservice.sendletter returnlet.setViewName("redirect:letter/letterreturn");
	 * return returnlet; }
	 */
}
