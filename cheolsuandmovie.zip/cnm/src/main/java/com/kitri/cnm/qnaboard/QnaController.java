package com.kitri.cnm.qnaboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class QnaController {
	@Resource(name = "qnaService")
	private QnaService qnaservice;

	public void setQnaService(QnaService qnaservice) {
		this.qnaservice = qnaservice;
	}

	@RequestMapping(value = "/qna/QNABoard_Main.do")
	public ModelAndView QNABoard_Main(@RequestParam(value = "currentPage") int currentPage, String tags) {
		ModelAndView mav = new ModelAndView();

		int intPage = currentPage;
		// 게시물 총 목록수
		int sCount = 0;
		if (tags != null) {
			sCount = qnaservice.findTagCount(tags);	
		}else {
			sCount = qnaservice.findCount();
		}
		// 총페이지수계산
		int totalPage = 0;
		int cntPerPage = 10;// 1페이지별 5건씩 보여준다
		totalPage = (int) Math.ceil((double) sCount / cntPerPage);

		// 페이지그룹에서 쓰일 시작페이지값, 끝페이지값계산
		int cntPerPageGroup = 5; // 페이지그룹별 5페이지씩 보여준다
		int endRow = (cntPerPage * intPage) - 1;
		int startRow = (endRow + 1) - cntPerPage;
		int startPage = ((int)(currentPage-1)/cntPerPageGroup)*cntPerPageGroup+1;
		int endPage = startPage + cntPerPageGroup - 1;
		if (endPage > totalPage) {
			endPage = totalPage;
		}
		if (intPage == totalPage) {
			cntPerPageGroup = sCount % cntPerPage;
		}
		ArrayList<QnaVO> list = null;
		if (tags != null) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("tags", tags);
			map.put("intPage", intPage);
			list = qnaservice.selectTag(map);
		} else {
			list = qnaservice.selectAll(intPage);
		}
		ArrayList<TagVO> list1 = qnaservice.selectTagAll();
		mav.addObject("list", list);
		mav.addObject("list1", list1);
		
		PageBean pb = new PageBean();
		pb.setCurrentPage(intPage);// 현재페이지
		pb.setTotalPage(totalPage); // 총페이지
		pb.setList(list); // 목록
		pb.setStartPage(startPage); // 시작페이지
		pb.setEndPage(endPage); // 끝페이지
		
		mav.addObject("pagebean", pb);
		mav.setViewName("qna/QNABoard_Main");
		return mav;
	}

	@RequestMapping(value = "/qna/QNABoard_Write.do")
	public ModelAndView QNABoard_Write() {
		ModelAndView mav = new ModelAndView();
		ArrayList<TagVO> list1 = qnaservice.selectTagAll();
		mav.addObject("list1", list1);
		mav.setViewName("qna/QNABoard_Write");
		return mav;
	}

	@RequestMapping(value = "/qna/QNABoard_Write_My.do")
	public ModelAndView QNABoard_Write_Result(HttpServletRequest req, @ModelAttribute QnaVO qna) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView();
		qna.setP_seq(0);
		qna.setUser_id(id);
		qnaservice.insert(qna);

		mav.setViewName("redirect:/qna/QNABoard_Main.do?currentPage=1");
		return mav;
	}

	@RequestMapping(value = "/qna/QNABoard_My.do")
	public ModelAndView QNABoard_My(HttpServletRequest req, @ModelAttribute QnaVO qna) {
		ModelAndView mav = new ModelAndView();
		ArrayList<TagVO> list1 = qnaservice.selectTagAll();

		mav.addObject("list1", list1);

		int seq = Integer.parseInt((String) req.getParameter("seq"));
		mav.addObject("seq", qna.getSeq());

		qnaservice.updateHit(seq);

		QnaVO vlist = qnaservice.selectMy(seq);
		mav.addObject("vlist", vlist);

		mav.setViewName("qna/QNABoard_My");
		return mav;
	}

	@RequestMapping(value = "/qna/QNABoard_Delete.do")
	public ModelAndView QNABoard_Delete(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		int seq = Integer.parseInt((String) req.getParameter("seq"));
		qnaservice.delete(seq);
		mav.setViewName("redirect:/qna/QNABoard_Main.do?currentPage=1");
		return mav;
	}

	@RequestMapping(value = "/qna/QNABoard_Write_Update.do")
	public ModelAndView QNABoard_Write_Update(HttpServletRequest req, @ModelAttribute QnaVO qna) {
		ModelAndView mav = new ModelAndView();
		ArrayList<TagVO> list1 = qnaservice.selectTagAll();
		mav.addObject("list1", list1);

		int seq = Integer.parseInt((String) req.getParameter("seq"));
		mav.addObject("seq", qna.getSeq());

		QnaVO vlist = qnaservice.selectMy(seq);
		mav.addObject("vlist", vlist);

		mav.setViewName("qna/QNABoard_Edit_Write");
		return mav;
	}

	@RequestMapping(value = "/qna/QNABoard_Update.do")
	public ModelAndView QNABoard_Update(HttpServletRequest req, @ModelAttribute QnaVO qna) {
		ModelAndView mav = new ModelAndView();
		qnaservice.update(qna);
		mav.setViewName("redirect:/qna/QNABoard_Main.do?currentPage=1");
		return mav;
	}

	@RequestMapping(value = "/qna/QNABoard_C_Write.do")
	public ModelAndView QNABoard_C_Write(HttpServletRequest req, CommentVO cmt) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView();
		cmt.setUser_id(id);
		qnaservice.insertCmt(cmt);
		mav.setViewName("qna/writeresult");
		return mav;
	}

	@RequestMapping(value = "/qna/getcomment.do")
	public ModelAndView getComment(int seq) {
		ModelAndView mav = new ModelAndView();
		ArrayList<CommentVO> cmtlist = qnaservice.selectCmtAll(seq);
		mav.addObject("cmtlist", cmtlist);
		mav.setViewName("qna/commentresult");
		return mav;
	}

	@RequestMapping(value = "/qna/qnaboard_c_delete.do")
	public ModelAndView QNABoard_C_Delete(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		int c_seq = Integer.parseInt((String) req.getParameter("c_seq"));
		qnaservice.deleteCmt(c_seq);
		mav.setViewName("qna/deleteresult");
		return mav;
	}
	
	@RequestMapping(value = "/qna/qnaboard_re_write.do")
	public ModelAndView QNABoard_Re_Write() {
		ModelAndView mav = new ModelAndView();
		ArrayList<TagVO> list1 = qnaservice.selectTagAll();
		mav.addObject("list1", list1);

		mav.setViewName("qna/QNABoard_Re_Write");
		return mav;
	}

	@RequestMapping(value = "/qna/qnaboard_re_result.do")
	public ModelAndView QNABoard_Re_Result(HttpServletRequest req, @ModelAttribute QnaVO qna) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView();
		qna.setP_seq(qna.getSeq());
		qna.setUser_id(id);
		qna.setTags(qna.getTags());
		qnaservice.insert(qna);

		mav.setViewName("redirect:/qna/QNABoard_Main.do?currentPage=1");
		
		return mav;
	}
}
