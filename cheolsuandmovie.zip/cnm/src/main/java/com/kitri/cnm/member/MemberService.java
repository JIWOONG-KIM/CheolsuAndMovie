package com.kitri.cnm.member;


import java.util.List;


public interface MemberService {
	void addMember(MemberVO m);
	
	MemberVO editMemberform(String id);
	
	void editMember(MemberVO m);
	
	MemberVO getMember(String id);
	
	List<FriendVO> searchid(String id);
	
	void reqfriend(FriendVO f);
	
	List<String> friendreqlist(String id);
	
	List<String> friendreslist(String id);
	
	void friendpermit(FriendVO f);
	
	int listcnt();
	
	List<MemberVO> memberlist(int currentPage);
	
	void frienddel(FriendVO f);
}
