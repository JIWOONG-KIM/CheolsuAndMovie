package com.kitri.cnm.imgboard;

import java.sql.Date;

public class ImgBoardVO {
	private int seq;
	private String user_id;
	private String p_title;
	private String p_file_path;
	private String p_content;
	private Date p_log_time;
	private int p_hit;
	private String thumbNail;
	private String p_text;


	public ImgBoardVO() {
	}

	public ImgBoardVO(int seq, String user_id, String p_title, String p_file_path, String p_content, Date p_log_time,
			int p_hit, String thumbNail, String p_text) {
		super();
		this.seq = seq;
		this.user_id = user_id;
		this.p_title = p_title;
		this.p_file_path = p_file_path;
		this.p_content = p_content;
		this.p_log_time = p_log_time;
		this.p_hit = p_hit;
		this.thumbNail = thumbNail;
		this.p_text = p_text;
	}

	@Override
	public String toString() {
		return "ImgBoardVO [seq=" + seq + ", user_id=" + user_id + ", p_title=" + p_title + ", p_file_path="
				+ p_file_path + ", p_content=" + p_content + ", p_log_time=" + p_log_time + ", p_hit=" + p_hit
				+ ", thumbNail=" + thumbNail + ", p_text=" + p_text + "]";
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getP_title() {
		return p_title;
	}

	public void setP_title(String p_title) {
		this.p_title = p_title;
	}

	public String getP_file_path() {
		return p_file_path;
	}

	public void setP_file_path(String p_file_path) {
		this.p_file_path = p_file_path;
	}

	public String getP_content() {
		return p_content;
	}

	public void setP_content(String p_content) {
		this.p_content = p_content;
	}

	public Date getP_log_time() {
		return p_log_time;
	}

	public void setP_log_time(Date p_log_time) {
		this.p_log_time = p_log_time;
	}

	public int getP_hit() {
		return p_hit;
	}

	public void setP_hit(int p_hit) {
		this.p_hit = p_hit;
	}

	public String getThumbNail() {
		return thumbNail;
	}

	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}

	public String getP_text() {
		return p_text;
	}

	public void setP_text(String p_text) {
		this.p_text = p_text;
	}

	

}
