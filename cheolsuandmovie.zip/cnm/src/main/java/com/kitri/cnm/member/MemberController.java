package com.kitri.cnm.member;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class MemberController {
	@Resource(name = "memService")
	private MemberService memservice;

	public void setMemService(MemberService memservice) {
		this.memservice = memservice;
	}
	
	@RequestMapping(value = "/movie/main.do")
	public String mainpage() {
		return "redirect:/movie/boxoffice.do";
	}
	
	@RequestMapping(value = "/member/joinform.do")
	public String joinform(HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.setAttribute("idCheck", false);
		return "member/joinform";
	}
	
	@RequestMapping(value = "/member/join.do")
	public String join(MemberVO m) {
		memservice.addMember(m);
		return "redirect:/movie/boxoffice.do";
	}
	
	@RequestMapping(value = "/member/loginform.do")
	public String loginForm() {
		return "member/login";
	}
	
	@RequestMapping(value = "/member/login.do")
	public String login(HttpServletRequest req, MemberVO m) {
		MemberVO m2 = memservice.getMember(m.getId());
		if (m2 == null || !m2.getPwd().equals(m.getPwd())) {
			System.out.println("로그인 실패");
			return "member/alert";
		} else {
			HttpSession session = req.getSession();
			session.setAttribute("id", m2.getId());
			System.out.println(m2.getId());
			if(m2.getId().equals("admin")) {
				session.setAttribute("type", 2);
			}else {
				session.setAttribute("type", 1);
			}
			return "redirect:"+req.getHeader("referer");
			//return "redirect:searchform.do";
		}
	}
	
	@RequestMapping(value = "/member/idCheck.do")
	public ModelAndView idCheck(HttpServletRequest req, @RequestParam(value = "id") String id) {
		System.out.println(id);
		System.out.println("Controller 진입");
		HttpSession session = req.getSession(false);
		ModelAndView mav = new ModelAndView("member/idCheck");
		String result = "";
		MemberVO m = memservice.getMember(id);
		if (m == null) {
			result = "사용가능";
			session.setAttribute("idCheck", true);
		} else {
			result = "사용불가능";
			session.setAttribute("idCheck", false);
		}
		System.out.println(session.getAttribute("idCheck"));
		mav.addObject("result", result);
		return mav;
	}
	
	@RequestMapping(value = "/member/logout.do")
	public String logout(HttpServletRequest req){
		HttpSession session = req.getSession(false);
		session.removeAttribute("id");
		session.invalidate();
		return "redirect:/movie/boxoffice.do";
	}
	
/*	@RequestMapping(value = "/member/withdraw.do")
	public String withdraw(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		session.removeAttribute("id");
		
	}*/
	
	@RequestMapping(value = "/member/editmemberform.do")
	public ModelAndView editmemberform(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView("member/editform");
		MemberVO m = memservice.editMemberform(id);
		mav.addObject("m", m);
		return mav;
	}
	
	@RequestMapping(value = "/member/editmember.do")
	public String editmember(MemberVO m) {
		System.out.println(m);
		memservice.editMember(m);
		return "redirect:/movie/boxoffice.do";
	}
	
	
	@RequestMapping(value = "/member/friendlist.do")
	public ModelAndView searchform(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView("member/friend");
		List<FriendVO> friend = memservice.searchid(id);
		List<String> list = new ArrayList<String>();
		for(int i = 0; friend.size() > i; i++) {
			if(friend.get(i).getId().equals(id)) {
				list.add(friend.get(i).getFr_id());
			}else if(friend.get(i).getFr_id().equals(id)){
				list.add(friend.get(i).getId());
			}
		}
		System.out.println(list);
		mav.addObject("friend", list);
		return mav;
	}
	
	@RequestMapping(value = "/member/friendreq.do")
	public ModelAndView searchid(HttpServletRequest req, @RequestParam(value = "fr_id") String fr_id, FriendVO f) {
		HttpSession session = req.getSession(false);
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView("member/friendreqresult");
		f.setId(id);
		f.setFr_id(fr_id);
		String result ="";
		if(memservice.getMember(fr_id)==null) {
			result = "존재하지 않는 ID 입니다.";
		}else {
			result = "전송 성공";
			memservice.reqfriend(f);
		}
		mav.addObject("result", result);
		return mav;
	}
	
	@RequestMapping(value = "/member/friendreqlist.do")
	public ModelAndView friendreqlist(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView("member/friendreq");
		List<String> frlist = memservice.friendreqlist(id);
		System.out.println(frlist);
		mav.addObject("frlist", frlist);
		return mav;
	}
	
	@RequestMapping(value = "member/friendreslist.do")
	public ModelAndView friendreslist(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView("member/friendres");
		List<String> frlist = memservice.friendreslist(id);
		mav.addObject("frlist",frlist);
		return mav;
	}
	
	@RequestMapping(value = "member/friendpermit.do")
	public String friendpermit(HttpServletRequest req, @RequestParam(value = "reqfriend") String reqfriend, FriendVO f) {
		HttpSession session = req.getSession(false);
		String id = (String) session.getAttribute("id");
		f.setId(reqfriend);
		f.setFr_id(id);
		memservice.friendpermit(f);
		return "member/friendres";
	}
	
	@RequestMapping(value = "member/frienddel.do")
	public String frienddel(HttpServletRequest req, @RequestParam(value = "friend") String friend, FriendVO f) {
		HttpSession session = req.getSession(false);
		String id = (String) session.getAttribute("id");
		f.setId(id);
		f.setFr_id(friend);
		memservice.frienddel(f);
		f.setId(friend);
		f.setFr_id(id);
		memservice.frienddel(f);
		return "redirect:/member/friendlist.do";
	}
	
	
	@RequestMapping(value = "member/memberlist.do")
	public ModelAndView memberlist(HttpServletRequest req, @RequestParam(value = "currentPage") int currentPage) {
		ModelAndView mav = new ModelAndView("member/memberlist");
		PageVO page = new PageVO();
		int totalCount = memservice.listcnt(); //10
		int cntPerPage=5;//페이지별 5건씩 보여준다
		int totalPage = (int)Math.ceil((double)totalCount/ cntPerPage); 
		
		int cntPerPageGroup=3; //페이지그룹별 5페이지씩 보여준다
		/*int startPage = (int)Math.floor((double)(currentPage)/(cntPerPageGroup))*cntPerPageGroup+1;*/
		int startPage = ((int)(currentPage-1)/cntPerPageGroup)*cntPerPageGroup+1;
		int endPage = startPage+cntPerPageGroup-1;
		

		if(endPage > totalPage) {
			endPage = totalPage;
		}

		List<MemberVO> memberlist = memservice.memberlist(currentPage);// 현재페이지의 내용

		page.setCurrentPage(currentPage);
		page.setTotalPage(totalPage);
		page.setList(memberlist);
		page.setStartPage(startPage);
		page.setEndPage(endPage);
		mav.addObject("page", page);
		return mav;
	}
}
