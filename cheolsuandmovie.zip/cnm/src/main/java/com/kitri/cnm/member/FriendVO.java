package com.kitri.cnm.member;

public class FriendVO {
	private String id;
	private String fr_id;
	private int type;

	public FriendVO() {
	}

	public FriendVO(String id, String fr_id, int type) {
		super();
		this.id = id;
		this.fr_id = fr_id;
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFr_id() {
		return fr_id;
	}

	public void setFr_id(String fr_id) {
		this.fr_id = fr_id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "FriendVO [id=" + id + ", fr_id=" + fr_id + ", type=" + type + "]";
	}

}
