package com.kitri.cnm.soc;



public class SocVO {
	private int letter_seq;
	private String user_id;
	private String title;
	private String content;
	private String rcv_id;
	private String write_date;
	private String read_date;
	private String readyn;
	private String sent_del;
	private String rcv_del;

	public SocVO() {
		
	}
	
	public SocVO(int letter_seq, String user_id, String title, String content, String rcv_id, String write_date,
			String read_date, String readyn, String sent_del, String rcv_del) {
		super();
		this.letter_seq = letter_seq;
		this.user_id = user_id;
		this.title = title;
		this.content = content;
		this.rcv_id = rcv_id;
		this.write_date = write_date;
		this.read_date = read_date;
		this.readyn = readyn;
		this.sent_del = sent_del;
		this.rcv_del = rcv_del;
	}

	public int getLetter_seq() {
		return letter_seq;
	}

	public void setLetter_seq(int letter_seq) {
		this.letter_seq = letter_seq;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRcv_id() {
		return rcv_id;
	}

	public void setRcv_id(String rcv_id) {
		this.rcv_id = rcv_id;
	}

	public String getWrite_date() {
		return write_date;
	}

	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}

	public String getRead_date() {
		return read_date;
	}

	public void setRead_date(String read_date) {
		this.read_date = read_date;
	}

	public String getReadyn() {
		return readyn;
	}

	public void setReadyn(String readyn) {
		this.readyn = readyn;
	}

	public String getSent_del() {
		return sent_del;
	}

	public void setSent_del(String sent_del) {
		this.sent_del = sent_del;
	}

	public String getRcv_del() {
		return rcv_del;
	}

	public void setRcv_del(String rcv_del) {
		this.rcv_del = rcv_del;
	}

	@Override
	public String toString() {
		return "SocVO [letter_seq=" + letter_seq + ", user_id=" + user_id + ", title=" + title + ", content=" + content
				+ ", rcv_id=" + rcv_id + ", write_date=" + write_date + ", read_date=" + read_date + ", readyn="
				+ readyn + ", sent_del=" + sent_del + ", rcv_del=" + rcv_del + "]";
	}

}
