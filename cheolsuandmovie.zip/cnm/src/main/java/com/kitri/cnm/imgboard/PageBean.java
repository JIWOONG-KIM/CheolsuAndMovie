package com.kitri.cnm.imgboard;

import java.util.List;

public class PageBean {

	private int currentPage;
	private int totalPage;
	private List<ImgBoardVO> list;
	private int startPage;
	private int endPage;
	private int pre;
	private int next;
	
	
	public int getPre() {
		return pre;
	}

	public void setPre(int pre) {
		this.pre = pre;
	}

	public int getNext() {
		return next;
	}

	public void setNext(int next) {
		this.next = next;
	}

	public PageBean() {
		super();
	}

	public PageBean(int currentPage, int totalPage, List<ImgBoardVO> list, int startPage, int endPage) {
		super();
		this.currentPage = currentPage;
		this.totalPage = totalPage;
		this.list = list;
		this.startPage = startPage;
		this.endPage = endPage;
	}

	@Override
	public String toString() {
		return "PageBean [currentPage=" + currentPage + ", totalPage=" + totalPage + ", startPage=" + startPage
				+ ", endPage=" + endPage + "]";
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public List<ImgBoardVO> getList() {
		return list;
	}

	public void setList(List<ImgBoardVO> list) {
		this.list = list;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	
	
	
	
}
