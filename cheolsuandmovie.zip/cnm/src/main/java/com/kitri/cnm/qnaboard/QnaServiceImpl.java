package com.kitri.cnm.qnaboard;

import java.util.ArrayList;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;

@Component("qnaService")
public class QnaServiceImpl implements QnaService {
	@Resource(name = "sqlSession")
	private SqlSession sqlSession;
	private QnaMapper qnaMapper;

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public ArrayList<QnaVO> selectAll(int page) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class);
		ArrayList<QnaVO> list = qnaMapper.getQnaBoards(page);
		return list;
	}
	
	@Override
	public ArrayList<TagVO> selectTagAll() {
		qnaMapper = sqlSession.getMapper(QnaMapper.class);
		ArrayList<TagVO> list1 = qnaMapper.getTagBoards();
		return list1;
	}
	
	public void insert(QnaVO qna) { 
		qnaMapper = sqlSession.getMapper(QnaMapper.class); 
		qnaMapper.insertQnaVO(qna); 
	}

	@Override
	public QnaVO selectMy(int seq) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class); 
		QnaVO vlist = qnaMapper.getQnaArticle(seq);
		return vlist;
	}

	@Override
	public void delete(int seq) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class); 
		qnaMapper.deleteQnaVO(seq);
	}

	@Override
	public void update(QnaVO qna) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class); 
		qnaMapper.updateQnaVO(qna);
	}

	@Override
	public void updateHit(int seq) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class); 
		qnaMapper.updateHit(seq);
	}

	@Override
	public ArrayList<CommentVO> selectCmtAll(int seq) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class);
		ArrayList<CommentVO> cntlist = qnaMapper.getCmtBoards(seq);
		return cntlist;
	}

	@Override
	public int findCount() {
		qnaMapper = sqlSession.getMapper(QnaMapper.class);
		int sCount = qnaMapper.selectCount();
		return sCount;
	}

	@Override
	public void insertCmt(CommentVO cmt) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class); 
		qnaMapper.insertCmtVO(cmt); 
	}

	@Override
	public void deleteCmt(int c_seq) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class); 
		qnaMapper.deleteCmtVO(c_seq); 
	}

	@Override
	public ArrayList<QnaVO> selectTag(Map<String, Object> map) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class);
		ArrayList<QnaVO> selecttag = qnaMapper.selectTagVO(map);
		return selecttag;
	}

	@Override
	public int findTagCount(String tags) {
		qnaMapper = sqlSession.getMapper(QnaMapper.class);
		int stCount = qnaMapper.selectTagCount(tags);
		return stCount;
	}
}
