package com.kitri.cnm.qnaboard;

import java.util.ArrayList;
import java.util.Map;

public interface QnaService {
	//qna board
	ArrayList<QnaVO> selectAll(int Page);
	ArrayList<TagVO> selectTagAll();
	void insert(QnaVO qna);
	QnaVO selectMy(int seq);
	void delete(int seq);
	void update(QnaVO qna);
	void updateHit(int seq);
	ArrayList<QnaVO> selectTag(Map<String, Object> map);
	
	//qna comment
	ArrayList<CommentVO> selectCmtAll(int seq);
	void insertCmt(CommentVO cmt);
	void deleteCmt(int c_seq);

	//qna board paging
	int findCount();
	int findTagCount(String tags);
}
