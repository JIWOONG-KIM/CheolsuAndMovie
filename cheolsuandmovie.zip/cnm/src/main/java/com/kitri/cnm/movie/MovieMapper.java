package com.kitri.cnm.movie;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface MovieMapper {
	public void getMovie(int seq);

	public void insertMyMovie(MovieVO movie);

	public Integer checkList(MovieVO movie);

	public void updateMyMovie(MovieVO movie);
	
	public List<String> getMembers(String id);

	public List<MovieVO> getList(String id);
	
	public void updaterate(MovieVO m);

	public void delmovie(int seq);
}
