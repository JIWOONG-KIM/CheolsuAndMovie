package com.kitri.cnm.soc;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface SocMapper {

	SocVO getfindLetter(int letter_seq);
	void insertletter(SocVO sv);
	List<SocVO> selectletter(HashMap<String, Object> map);
	void deleteletter(int letter_seq);
	void updateletter(int letter_seq);
	void updatedate(int letter_seq);
	String selectrcvid(int letter_seq);
	List<SocVO> myrcvletter(HashMap<String, Object> map);
	List<SocVO> mysendletter(HashMap<String, Object> map);
	List<SocVO> mydontread(HashMap<String, Object> map);
	int listcnt(String user_id);
	int listcnt2(String user_id);
	String rcvid(String user_id);
	String srchid(String id);
}
