package com.kitri.cnm.soc;

import java.util.HashMap;
import java.util.List;

public interface SocService {
	
	SocVO getletter(int letter_seq);
	
	void writeletter(SocVO sv);
	
	List<SocVO> findletter(HashMap<String, Object> map);

	void removeletter(int letter_seq);
	
	void readletter(int letter_seq);
	
	void readdate(int letter_seq);
	
	String findrcvid(int letter_seq);
	
	List<SocVO> getrcvlet(HashMap<String, Object> map);
	
	List<SocVO> getsendlet(HashMap<String, Object> map);
	
	List<SocVO> getdontread(HashMap<String, Object> map);

	int listcnt(String user_id);
	
	int listcnt2(String user_id);
	
	String rcvletid(String user_id);
}
