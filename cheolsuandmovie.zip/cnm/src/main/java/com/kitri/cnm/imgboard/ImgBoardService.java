package com.kitri.cnm.imgboard;

import java.util.List;


public interface ImgBoardService {
	
	void uploadImg(ImgBoardVO i);	
	
	ImgBoardVO getImg(int seq);	
	
	void editImg(ImgBoardVO i);
	
	void delImg(int seq);
	
	List<ImgBoardVO> findAll(int page);
	
	int findCount();
	
	List<CommentVO> getCmt(int seq);
	
	void insertCmt(CommentVO cmt);
	
	void delete(int c_seq);
}
