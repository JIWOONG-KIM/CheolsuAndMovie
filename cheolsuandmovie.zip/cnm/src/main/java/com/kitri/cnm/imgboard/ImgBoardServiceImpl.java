package com.kitri.cnm.imgboard;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;



@Component("imgService")
public class ImgBoardServiceImpl implements ImgBoardService {
	@Resource(name = "sqlSession")
	
	private SqlSession sqlSession;
	private ImgBoardMapper imgboardMapper;

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

/*	@Override
	public ImgBoardVO getImgBoard() {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		return imgboardMapper.getImgArticle(1);
	}*/
	
	@Override
	public void uploadImg(ImgBoardVO i) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		imgboardMapper.insert(i);
		
	}

	@Override
	public ImgBoardVO getImg(int seq) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		ImgBoardVO i = imgboardMapper.select(seq);
		return i;
	}

	@Override
	public void editImg(ImgBoardVO i) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		imgboardMapper.update(i);
		
	}

	@Override
	public void delImg(int seq) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		imgboardMapper.delete(seq);
		
	}


	@Override
	public List<ImgBoardVO> findAll(int page) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		ArrayList<ImgBoardVO> list = (ArrayList<ImgBoardVO>) imgboardMapper.selectAll(page);
		return list;
	}

	@Override
	public int findCount() {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		return imgboardMapper.selectCount();
	}

	@Override
	public List<CommentVO> getCmt(int seq) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		return imgboardMapper.getCmtb(seq);
	}

	@Override
	public void insertCmt(CommentVO cmt) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		imgboardMapper.insertCmt(cmt);
	}

	@Override
	public void delete(int c_seq) {
		imgboardMapper = sqlSession.getMapper(ImgBoardMapper.class);
		imgboardMapper.deleteCmt(c_seq);
	}


	



	
	
}
