package com.kitri.cnm.qnaboard;

import java.sql.Date;

public class CommentVO {
	private int c_seq;
	private int pc_seq;
	private String user_id;
	private String c_content;
	private String c_log_time;

	public CommentVO() {
	}

	public CommentVO(int c_seq, int pc_seq, String user_id, String c_content, String c_log_time) {
		super();
		this.c_seq = c_seq;
		this.pc_seq = pc_seq;
		this.user_id = user_id;
		this.c_content = c_content;
		this.c_log_time = c_log_time;
	}

	public int getC_seq() {
		return c_seq;
	}

	public void setC_seq(int c_seq) {
		this.c_seq = c_seq;
	}

	public int getPc_seq() {
		return pc_seq;
	}

	public void setPc_seq(int pc_seq) {
		this.pc_seq = pc_seq;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getC_content() {
		return c_content;
	}

	public void setC_content(String c_content) {
		this.c_content = c_content;
	}

	public String getC_log_time() {
		return c_log_time;
	}

	public void setC_log_time(String c_log_time) {
		this.c_log_time = c_log_time;
	}

	@Override
	public String toString() {
		return "CommentVO [c_seq=" + c_seq + ", pc_seq=" + pc_seq + ", user_id=" + user_id + ", c_content=" + c_content
				+ ", c_log_time=" + c_log_time + "]";
	}

}
