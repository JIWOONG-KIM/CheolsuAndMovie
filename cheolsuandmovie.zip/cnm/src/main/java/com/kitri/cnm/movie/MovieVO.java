package com.kitri.cnm.movie;

public class MovieVO {
	private int seq;
	private String user_id;
	private String title;
	private String subtitle;
	private String pubDate;
	private String image;
	private String director;
	private String actor;
	private String useRating;

	public MovieVO() {
	}

	public MovieVO(int seq, String user_id, String title, String subtitle, String pubDate, String image,
			String director, String actor, String useRating) {
		super();
		this.seq = seq;
		this.user_id = user_id;
		this.title = title;
		this.subtitle = subtitle;
		this.pubDate = pubDate;
		this.image = image;
		this.director = director;
		this.actor = actor;
		this.useRating = useRating;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getPubDate() {
		return pubDate;
	}

	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	public String getUseRating() {
		return useRating;
	}

	public void setUseRating(String useRating) {
		this.useRating = useRating;
	}

	@Override
	public String toString() {
		return "MovieVO [seq=" + seq + ", user_id=" + user_id + ", title=" + title + ", subtitle=" + subtitle
				+ ", pubDate=" + pubDate + ", image=" + image + ", director=" + director + ", actor=" + actor
				+ ", useRating=" + useRating + "]";
	}

}
