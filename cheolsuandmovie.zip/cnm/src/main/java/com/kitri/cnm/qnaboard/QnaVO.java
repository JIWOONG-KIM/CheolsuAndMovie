package com.kitri.cnm.qnaboard;

import java.sql.Date;

public class QnaVO {
	private int seq;
	private int p_seq;
	private String user_id;
	private String tags;
	private String title;
	private String content;
	private Date log_time;
	private int hit;
	private String tags_name;
	
	QnaVO(){}
	
	public QnaVO(int seq, int p_seq, String user_id, String tags, String title, String content, Date log_time, int hit,
			String tags_name) {
		super();
		this.seq = seq;
		this.p_seq = p_seq;
		this.user_id = user_id;
		this.tags = tags;
		this.title = title;
		this.content = content;
		this.log_time = log_time;
		this.hit = hit;
		this.tags_name = tags_name;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public int getP_seq() {
		return p_seq;
	}
	public void setP_seq(int p_seq) {
		this.p_seq = p_seq;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getLog_time() {
		return log_time;
	}
	public void setLog_time(Date log_time) {
		this.log_time = log_time;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getTags_name() {
		return tags_name;
	}
	public void setTags_name(String tags_name) {
		this.tags_name = tags_name;
	}
	@Override
	public String toString() {
		return "QnaVO [seq=" + seq + ", p_seq=" + p_seq + ", user_id=" + user_id + ", tags=" + tags + ", title=" + title
				+ ", content=" + content + ", log_time=" + log_time + ", hit=" + hit + ", tags_name=" + tags_name + "]";
	}
	
	

}
