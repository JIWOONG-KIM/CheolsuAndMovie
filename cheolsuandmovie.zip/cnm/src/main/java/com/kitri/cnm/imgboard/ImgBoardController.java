package com.kitri.cnm.imgboard;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ImgBoardController {
	@Resource(name = "imgService")
	private ImgBoardService imgservice;

	public void setImgService(ImgBoardService imgservice) {
		this.imgservice = imgservice;
	}
	
	//boardWrite로 페이지 전환 / 넘길 데이터는 id와 pwd 인데 나중에...
	@RequestMapping(value ="/img/writeView.do")
	public ModelAndView writeView() {
		ModelAndView mav = new ModelAndView("img/boardWrite");
	return mav;
	}
	
	//글 내용을 db에 저장 함.
	@RequestMapping(value="/img/article.do")
	public String ImgBoardVO(HttpServletRequest req, ImgBoardVO iv ) {
		String content = req.getParameter("content");
		String title = req.getParameter("subject");
		
		String user_id="dragonjin";
		String file_path="root";
		int p_hit = 10;		
		
		
		iv.setUser_id(user_id);
		iv.setP_title(title);
		iv.setP_file_path(file_path);
		iv.setP_hit(p_hit);
		iv.setP_content(content);
		
		imgservice.uploadImg(iv);
		System.out.println("db에 값 저장 됨 " + iv.getP_content());
		return "redirect:/img/list.do?currentPage=1";
	}
	
	
	@RequestMapping(value = "/img/list.do", method= {RequestMethod.POST, RequestMethod.GET})	
	public ModelAndView list(PageBean ipage, HttpServletRequest req, @RequestParam(value="currentPage")int currentPage) {
		
		ModelAndView mav = new ModelAndView("img/photoBoard");
		// 페이지 처리

		int intPage= currentPage;
		try {
			//게시물 총 목록수
			int totalCount = imgservice.findCount();
			
			//총페이지수 계산
			int totalPage = 0;
			int cntPerPage = 5;	//페이지별 5건씩 보여줌
			totalPage = (int)Math.ceil((double)totalCount / cntPerPage);
			
			//페이지그룹에서 쓰일 시작페이지값, 끝페이지값 계산
			int cntPerPageGroup = 5;
			int endRow = cntPerPage * intPage;
			int startRow = (endRow+1) - cntPerPage;
			int startPage = (int)Math.floor((double)(intPage) / (cntPerPageGroup + 1)) * cntPerPageGroup + 1;
			int endPage = startPage + cntPerPageGroup -1;
			if(endPage > totalPage) {
				endPage = totalPage;
			}
			
			int pre = 0;
			int next = 0;
			if(endPage < totalPage) {
				next = endPage+1;
			}else if(next == 0) {
				next = totalPage;
			}
			
			if(startPage > 1) {
				pre = startPage-1;
			}else if(pre == 0) {
				pre = 1;
			}
			
			ArrayList<ImgBoardVO> list = (ArrayList<ImgBoardVO>) imgservice.findAll(intPage);
			ArrayList<ImgBoardVO> list2 = new ArrayList<ImgBoardVO>();	//img 출력 list
			
			ipage.setCurrentPage(intPage);
			ipage.setTotalPage(totalPage);
			ipage.setList(list);
			ipage.setStartPage(startPage);
			ipage.setEndPage(endPage);
			ipage.setPre(pre);
			ipage.setNext(next);
			
		// img 추출
		for (ImgBoardVO imgBoardVO : list) {	
			String content = imgBoardVO.getP_content();
		if(content != null) {
			int idx = content.indexOf("<img");
			int idx2 = content.indexOf(">", idx);
			String thumbNail = "";
			thumbNail = content.substring(idx,idx2+1);
			System.out.println("thumbNail  : "  + thumbNail);
			imgBoardVO.setThumbNail(thumbNail);
			// p_content의 데이터를 <img>와 텍스트를 구별 한다. vo의 p_content는 img와 text를 모두 갖는다. thumbNail은 img이다. p_text를 만들어야 겠다.
			// replace로 <img>를 자르고 p_content에 넣는다.
			String p_text = null;
			String tx = content.replace(thumbNail, "");
			p_text = tx;
			System.out.println("p_content : " + p_text);
			imgBoardVO.setP_text(p_text);
			list2.add(imgBoardVO);
			mav.addObject("list",list2); // img 추출
		}
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		mav.addObject("pb", ipage);
		return mav;
	}
	
	@RequestMapping(value = "/img/boardDetail.do")
	public ModelAndView detail(HttpServletRequest req) {
		// 썸네일 이미지를 클릭하면 이미지가 확대 되서 나온다.
		// 글 내용도 나온다.
		// get 할 것 : id, req.getParameter("content"), ,req.getParameter("subject")
		//imgservice.getImg();
		// 기능 , 수정 , 삭제 , 댓글 가능
		
		String sequence = req.getParameter("seq");
		int seq = Integer.parseInt(sequence);
		
		ImgBoardVO imgvo =  imgservice.getImg(seq);	// 어떤 이미지를 가져 올 건지
		ModelAndView mav = new ModelAndView("img/photoDetail");

		
		String content = imgvo.getP_content();
		System.out.println(imgvo.getSeq());
		int idx = content.indexOf("<img");
		int idx2 = content.indexOf(">", idx);
		String thumbNail = null;
		thumbNail = content.substring(idx,idx2+1);
		imgvo.setThumbNail(thumbNail);
		String p_text = null;
		String tx = content.replace(thumbNail, "");
		p_text = tx;
		imgvo.setP_text(p_text);
		System.out.println("/img/boardDetail.do 동작 : "  + p_text);
		//
		mav.addObject("vo", imgvo);
		return mav;
	}
	
	@RequestMapping(value="/img/edit.do")
	public ModelAndView edit(@ModelAttribute ImgBoardVO imgboardvo, HttpServletRequest req ) {
		ModelAndView mav = new ModelAndView("img/boardUpdate");
		
		int seq = Integer.parseInt((String)req.getParameter("seq"));
		ImgBoardVO ivo = imgservice.getImg(seq);
		mav.addObject("seq", imgboardvo.getSeq());
		mav.addObject("editList", ivo);
		return mav;
	}
	
	@RequestMapping(value="/img/editComplete.do")
	public String complete(@ModelAttribute ImgBoardVO imgboardvo) {
		System.out.println("dd : " + imgboardvo);
        imgservice.editImg(imgboardvo);
		return "redirect:/img/list.do?currentPage=1";
	}
	
	@RequestMapping(value = "/img/delete.do", method=RequestMethod.GET)
	public String delete(HttpServletRequest req, @RequestParam(value="seq")String seq) {
		int sequence = Integer.parseInt(seq);
		System.out.println("탈퇴" + sequence);
		// 경고창 띄우기 해야한다.
		imgservice.delImg(sequence);
		return "redirect:/img/list.do?currentPage=1";
	}
	
	
	@RequestMapping(value="/comment/writeCmd.do")
	public ModelAndView writeComment(HttpServletRequest req, CommentVO cv) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView("img/write");
		if(id==null) {
			mav.setViewName("img/cmtfail");
		}else {
			mav.setViewName("img/write");
			cv.setUser_id(id);
			imgservice.insertCmt(cv);
		}
		System.out.println("seq1 : " + cv.getPc_seq());
		System.out.println("user : " + cv.getUser_id());
		return mav;
	}
	
	@RequestMapping(value="/comment/getcomment.do")
	public ModelAndView getComment(@RequestParam("pc_seq")int pc_seq) {
		System.out.println(pc_seq);
		ModelAndView mav = new ModelAndView("img/result");
		List<CommentVO> commentList = imgservice.getCmt(pc_seq);
		System.out.println("12312"+commentList);
		mav.addObject("cl", commentList);
		System.out.println("seq2 : " + pc_seq);
		return mav;
	}
	
	@RequestMapping(value="/comment/deleteCmd.do")
	public ModelAndView deleteCmd(HttpServletRequest req) {
		int c_seq = Integer.parseInt((String)req.getParameter("c_seq"));
		imgservice.delete(c_seq);
		ModelAndView mav = new ModelAndView("img/delete");
		System.out.println("seq3 : " + c_seq);
		return mav;
	}
	
}






