package com.kitri.cnm.imgboard;

import java.util.List;

import org.springframework.stereotype.Repository;


@Repository
public interface ImgBoardMapper {
	
	void insert(ImgBoardVO i);
	
	ImgBoardVO select(int seq);
	
	void delete(int seq);
	
	void update(ImgBoardVO i);
	
	List<ImgBoardVO> selectAll(int page);
	
	int selectCount();
	// comment
	List<CommentVO> getCmtb(int pc_seq);
	
	void insertCmt(CommentVO cmt);
	
	void deleteCmt(int c_seq);
}
