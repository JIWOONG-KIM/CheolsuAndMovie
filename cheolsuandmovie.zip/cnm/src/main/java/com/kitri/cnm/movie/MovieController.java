package com.kitri.cnm.movie;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MovieController {
	@Resource(name = "movService")
	private MovieService movservice;
	@Autowired
	private NmovieService nservice;

	public void setMovService(MovieService movservice) {
		this.movservice = movservice;
	}

	@RequestMapping(value = "/movie/boxoffice.do")
	public ModelAndView getBoxOffice() {
		ModelAndView mav = new ModelAndView();
		List<KmovieVO> klist = nservice.getBoxOffice();
		// System.out.println(klist);
		List<NmovieVO> nlist = new ArrayList<NmovieVO>();
		for (KmovieVO km : klist) {
			NmovieVO n = nservice.getMovieDetail(km.getMovieNm(), 0);
			/*
			 * int idx = n.getImage().lastIndexOf("/"); int idx2 = n.getImage().indexOf("_",
			 * idx); String imagenum = n.getImage().substring(idx+1, idx2);
			 * System.out.println(imagenum); n.setImage(
			 * "https://movie.naver.com/movie/bi/mi/photoViewPopup.nhn?movieCode="+imagenum)
			 * ; System.out.println(n.getImage());
			 */
			nlist.add(n);
		}
		mav.addObject("klist", klist);
		mav.addObject("nlist", nlist);
		// System.out.println(nlist.size());
		mav.setViewName("movie/boxoffice");
		return mav;
	}

	@RequestMapping(value = "/movie/list.do")
	public ModelAndView setMain(@RequestParam(required = false) String keyword, @RequestParam("page") int page) {
		ModelAndView mav = new ModelAndView("movie/main");
		List<NmovieVO> list = null;
		page = (page - 1) * 10 + 1;
		if (keyword != null) {
			list = nservice.searchMovie(keyword, 10, page);
			mav.addObject("movielist", list);
		}
		return mav;
	}

	@RequestMapping(value = "/movie/detail.do")
	public ModelAndView getDetail(@RequestParam("title") String keyword, @RequestParam("year") String year) {
		ModelAndView mav = new ModelAndView();
		if (keyword != null) {
			if (year.trim().isEmpty()) {
				year = "0";
			}
			NmovieVO nmovie = nservice.getMovieDetail(keyword, Integer.parseInt(year));
			mav.addObject("m", nmovie);
			mav.setViewName("movie/detail");
		}
		return mav;
	}

	@RequestMapping(value = "/movie/registmovie.do")
	public String registMovie(HttpServletRequest req, MovieVO mov) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("id");
		String old_url = (String) req.getAttribute("old_url");
		mov.setUser_id(id);
		movservice.insertMyMovie(mov);
		return "redirect:" + old_url;
	}

	@RequestMapping(value = "/movie/updatemovie.do")
	public String updateMovie(HttpServletRequest req, MovieVO mov) {
		String old_url = (String) req.getAttribute("old_url");
		movservice.updatetMyMovie(mov);
		return "redirect:" + old_url;
	}

	@RequestMapping(value = "/movie/check.do")
	public ModelAndView checkList(HttpServletRequest req, NmovieVO nmovie) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView();
		String old_url = req.getHeader("referer");
		MovieVO mov = new MovieVO();
		{
			mov.setTitle(nmovie.getTitle());
			mov.setSubtitle(nmovie.getSubtitle());
			mov.setImage(nmovie.getImage());
			mov.setPubDate(nmovie.getPubDate());
			mov.setActor(nmovie.getActor());
			mov.setDirector(nmovie.getDirector());
			mov.setUseRating(nmovie.getUseRating());
		}
		mov.setUser_id(id);
		int seq = movservice.checkList(mov);
		if (seq > 0) {
			mav.setViewName("forward:updatemovie.do");
			mov.setSeq(seq);
		} else {
			mav.setViewName("forward:registmovie.do");
		}
		req.setAttribute("old_url", old_url);
		mav.addObject("old_url", old_url);
		mav.addObject("mov", mov);
		return mav;
	}

	@RequestMapping(value = "/movie/recomend.do")
	public ModelAndView recomendMovie(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		ModelAndView mav = new ModelAndView();
		if (session != null) {
			String id = (String) session.getAttribute("id");
			List<String> members = movservice.getMembers(id);
			double topsimil = 0;
			String topsimilid = null;
			List<MovieVO> myList = movservice.getList(id);
			if (members != null && myList!=null) {
				for (String other : members) {
					List<MovieVO> otherList = movservice.getList(other);
					double simil = getSimilarity(myList, otherList);
					if (simil > topsimil) {
						topsimil = simil;
						topsimilid = other;
					}
				}
				if (topsimilid != null) {
					List<MovieVO> topList = movservice.getList(topsimilid);
					System.out.println("[" + topsimilid + "]" + topsimil);
					List<MovieVO> list = getRecomend(myList, topList);
					int r = (int) (Math.random() * list.size());
					System.out.println("recomend:::" + list);
					MovieVO m = list.get(r);
					/*
					 * mav.addObject("recMovie", recomendMovie);
					 * System.out.println(recomendMovie.getTitle()); mav.addObject("predictRating",
					 * Double.parseDouble(recomendMovie.getUseRating()) * topsimil);
					 * System.out.println(Double.parseDouble(recomendMovie.getUseRating()) *
					 * topsimil);
					 */
					NmovieVO recomendedMovie = nservice.getMovieDetail(m.getTitle(), Integer.parseInt(m.getPubDate()));
					mav.addObject("m", recomendedMovie);
					mav.setViewName("movie/recomend");
				}else {
					mav.setViewName("movie/failrecomend");
				}
			}else {
				mav.setViewName("movie/failrecomend");
			}
		}
		return mav;
	}

	@RequestMapping(value = "/movie/update.do")
	public ModelAndView updateRating(MovieVO m) {
		movservice.updateRating(m);
		return new ModelAndView("redirect:/movie/mymovie.do");
	}

	@RequestMapping(value = "/movie/mymovie.do")
	public ModelAndView getMyMovie(HttpServletRequest req) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("id");
		ModelAndView mav = new ModelAndView();
		List<MovieVO> list = movservice.getList(id);
		mav.addObject("list", list);
		mav.setViewName("movie/mymovie");
		// System.out.println(nservice.getBoxOffice());
		return mav;
	}
	
	@RequestMapping(value="/movie/delmymovie.do")
	public String delMyMovie(@RequestParam("seq")int seq) {
		movservice.delMyMovie(seq);
		return "redirect:/movie/mymovie.do";
	}

	public double getSimilarity(List<MovieVO> my, List<MovieVO> other) {

		// System.out.println("my" + my);
		// System.out.println("other" + other);
		// 피어슨 상관계수를 이용한 유사도 계산
		int sumX = 0; // X의 합
		int sumY = 0; // Y의 합
		int sumPowX = 0; // X 제곱의 합
		int sumPowY = 0; // Y 제곱의 합
		int sumXY = 0; // X*Y의 합
		int count = 0; // 영화 개수

		for (MovieVO m : my) {
			for (MovieVO m2 : other) {
				if (m.getTitle().equals(m2.getTitle()) && m.getPubDate().equals(m2.getPubDate())) {// 같은 영화를 평가 했을 경우
					int myRate = Integer.parseInt(m.getUseRating());
					int otherRate = Integer.parseInt(m2.getUseRating());
					sumX += myRate;
					sumY += otherRate;
					sumPowX += Math.pow(myRate, 2);
					sumPowY += Math.pow(otherRate, 2);
					sumXY += myRate * otherRate;
					count++;
					// System.out.println("a");
				}
			}
		}
		double result = 0;
		if (count > 0)
			result = (sumXY - ((sumX * sumY) / count))
					/ (Math.sqrt((sumPowX - (Math.pow(sumX, 2) / count)) * (sumPowY - (Math.pow(sumY, 2) / count))));
		System.out.println(result);
		if (count > 0) {
			return result;
		} else {
			return -3;
		}
	}

	public List<MovieVO> getRecomend(List<MovieVO> my, List<MovieVO> other) {
		for (MovieVO m : my) {
			other.removeIf(m2 -> m2.getTitle().equals(m.getTitle()));
		}
		/*
		 * List<MovieVO> list = new ArrayList<MovieVO>(); int rate = 0; for (MovieVO m :
		 * other) { // System.out.println(m.getTitle() + ":::" + m.getUseRating()); if
		 * (Integer.parseInt(m.getUseRating()) > rate) { rate =
		 * Integer.parseInt(m.getUseRating()); list.clear(); list.add(m); } else if
		 * (Integer.parseInt(m.getUseRating()) == rate) { list.add(m); } }
		 */
		return other;
	}
}
