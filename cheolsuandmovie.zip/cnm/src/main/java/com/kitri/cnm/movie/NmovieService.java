package com.kitri.cnm.movie;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

@Service
public class NmovieService {
	private static String clientID = "ZoCwxQje3vhp2J0HUxbU";
	private static String clientSecret = "BzKKioN_L4";
	URL url;
	URLConnection urlConn;
	XmlPullParserFactory factory;
	XmlPullParser parser;

	public void con(String keyword, int yearfrom, int yearto, int display, int start) {
		try {
			url = new URL("https://openapi.naver.com/v1/search/movie.xml?query=" + URLEncoder.encode(keyword, "UTF-8")
					+ (yearfrom != 0 ? "&yearfrom=" + yearfrom : "") + (yearto != 0 ? "&yearto=" + yearto : "")
					+ (display != 0 ? "&display=" + display : "") + (start != 0 ? "&start=" + start : ""));
			urlConn = url.openConnection();
			urlConn.setRequestProperty("X-Naver-Client-Id", clientID);
			urlConn.setRequestProperty("X-Naver-Client-Secret", clientSecret);
			factory = XmlPullParserFactory.newInstance();
			parser = factory.newPullParser();
			parser.setInput(new InputStreamReader(urlConn.getInputStream()));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public List<NmovieVO> searchMovie(String keyword, int display, int start) {
		List<NmovieVO> list = null;
		con(keyword, 0, 0, display, start);
		int eventType;
		try {
			eventType = parser.getEventType();

			NmovieVO nmovie = null;
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.END_DOCUMENT:
					break;
				case XmlPullParser.START_DOCUMENT:
					list = new ArrayList<NmovieVO>();
					break;
				case XmlPullParser.END_TAG: {
					String tag = parser.getName();
					if (tag.equals("item")) {
						list.add(nmovie);
						nmovie = null;
					}
				}
				case XmlPullParser.START_TAG: {
					String tag = parser.getName();
					if ("item".equals(tag)) {
						nmovie = new NmovieVO();
						break;
					} else if ("title".equals(tag)) {
						if (nmovie != null)
							nmovie.setTitle(parser.nextText());
						break;
					} else if ("link".equals(tag)) {
						if (nmovie != null)
							nmovie.setLink(parser.nextText());
						break;
					} else if ("image".equals(tag)) {
						if (nmovie != null) {
							nmovie.setImage(parser.nextText());
						}
						break;
					} else if ("subtitle".equals(tag)) {
						if (nmovie != null)
							nmovie.setSubtitle(parser.nextText());
						break;
					} else if ("pubDate".equals(tag)) {
						if (nmovie != null)
							nmovie.setPubDate(parser.nextText());
						break;
					} else if ("director".equals(tag)) {
						if (nmovie != null)
							nmovie.setDirector(parser.nextText());
						break;
					} else if ("actor".equals(tag)) {
						if (nmovie != null)
							nmovie.setActor(parser.nextText());
						break;
					} else if ("userRating".equals(tag)) {
						if (nmovie != null) {
							nmovie.setUseRating(parser.nextText());
						}
						break;
					}
				}
				}
				eventType = parser.next();
			}
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public NmovieVO getMovieDetail(String keyword, int year) {
		keyword = keyword.replaceAll("&amp;", "&");
		// System.out.println(keyword + "(" + year + ")");
		con(keyword, year, year, 1, 1);
		int eventType;
		try {
			eventType = parser.getEventType();
			NmovieVO nmovie = null;
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.END_DOCUMENT:
					break;
				case XmlPullParser.START_DOCUMENT:
					break;
				case XmlPullParser.END_TAG: {
					String tag = parser.getName();
					if (tag.equals("item")) {
						return nmovie;
					}
				}
				case XmlPullParser.START_TAG: {
					String tag = parser.getName();
					if ("item".equals(tag)) {
						nmovie = new NmovieVO();
						break;
					} else if ("title".equals(tag)) {
						if (nmovie != null)
							nmovie.setTitle(parser.nextText());
						break;
					} else if ("link".equals(tag)) {
						if (nmovie != null)
							nmovie.setLink(parser.nextText());
						break;
					} else if ("image".equals(tag)) {
						if (nmovie != null) {
							nmovie.setImage(parser.nextText());
						}
						break;
					} else if ("subtitle".equals(tag)) {
						if (nmovie != null)
							nmovie.setSubtitle(parser.nextText());
						break;
					} else if ("pubDate".equals(tag)) {
						if (nmovie != null)
							nmovie.setPubDate(parser.nextText());
						break;
					} else if ("director".equals(tag)) {
						if (nmovie != null)
							nmovie.setDirector(parser.nextText());
						break;
					} else if ("actor".equals(tag)) {
						if (nmovie != null)
							nmovie.setActor(parser.nextText());
						break;
					} else if ("userRating".equals(tag)) {
						if (nmovie != null) {
							nmovie.setUseRating(parser.nextText());
						}
						break;
					}
				}
				}
				eventType = parser.next();
			}
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return null;
	}

	public List<KmovieVO> getBoxOffice() {
		SimpleDateFormat dformat = new SimpleDateFormat("yyyymmdd");
		String today = dformat.format(new Date());
		List<KmovieVO> list = new ArrayList<>();
		try {
			url = new URL(
					"http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.xml?key=3113723f61b559ee9c704921321d2ad6&targetDt="
							+ today);
			urlConn = url.openConnection();
			factory = XmlPullParserFactory.newInstance();
			parser = factory.newPullParser();
			parser.setInput(new InputStreamReader(urlConn.getInputStream()));
			int eventType;
			eventType = parser.getEventType();
			KmovieVO kmovie = null;
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.END_DOCUMENT:
					break;
				case XmlPullParser.START_DOCUMENT:
					break;
				case XmlPullParser.END_TAG: {
					String tag = parser.getName();
					if (tag.equals("dailyBoxOffice")) {
						list.add(kmovie);
						kmovie = null;
					}
				}
				case XmlPullParser.START_TAG: {
					String tag = parser.getName();
					if ("dailyBoxOffice".equals(tag)) {
						kmovie = new KmovieVO();
						break;
					} else if ("rnum".equals(tag)) {
						if (kmovie != null)
							kmovie.setRnum(parser.nextText());
						break;
					} else if ("rank".equals(tag)) {
						if (kmovie != null)
							kmovie.setRank(parser.nextText());
						break;
					} else if ("rankInten".equals(tag)) {
						if (kmovie != null) {
							kmovie.setRankInten(parser.nextText());
						}
						break;
					} else if ("rankOldAndNew".equals(tag)) {
						if (kmovie != null)
							kmovie.setRankOldAndNew(parser.nextText());
						break;
					} else if ("movieCd".equals(tag)) {
						if (kmovie != null)
							kmovie.setMovieCd(parser.nextText());
						break;
					} else if ("movieNm".equals(tag)) {
						if (kmovie != null)
							kmovie.setMovieNm(parser.nextText());
						break;
					} else if ("openDt".equals(tag)) {
						if (kmovie != null)
							kmovie.setOpenDt(parser.nextText());
						break;
					} else if ("salesAmt".equals(tag)) {
						if (kmovie != null) {
							kmovie.setSalesAmt(parser.nextText());
						}
						break;
					} else if ("salesShare".equals(tag)) {
						if (kmovie != null) {
							kmovie.setSalesShare(parser.nextText());
						}
						break;
					} else if ("salesInten".equals(tag)) {
						if (kmovie != null) {
							kmovie.setSalesInten(parser.nextText());
						}
						break;
					} else if ("salesChange".equals(tag)) {
						if (kmovie != null) {
							kmovie.setSalesChange(parser.nextText());
						}
						break;
					} else if ("audiCnt".equals(tag)) {
						if (kmovie != null) {
							kmovie.setAudiCnt(parser.nextText());
						}
						break;
					} else if ("audiInten".equals(tag)) {
						if (kmovie != null) {
							kmovie.setAudiInten(parser.nextText());
						}
						break;
					} else if ("audiChange".equals(tag)) {
						if (kmovie != null) {
							kmovie.setAudiChange(parser.nextText());
						}
						break;
					} else if ("audiAcc".equals(tag)) {
						if (kmovie != null) {
							kmovie.setAudiAcc(parser.nextText());
						}
						break;
					} else if ("scrnCnt".equals(tag)) {
						if (kmovie != null) {
							kmovie.setScrnCnt(parser.nextText());
						}
						break;
					} else if ("showCnt".equals(tag)) {
						if (kmovie != null) {
							kmovie.setShowCnt(parser.nextText());
						}
						break;
					}

				}
				}
				eventType = parser.next();
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}
}
