package com.kitri.cnm.qnaboard;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface QnaMapper {
	ArrayList<QnaVO> getQnaBoards(int page);
	ArrayList<TagVO> getTagBoards();
	void insertQnaVO(QnaVO qna);
	QnaVO getQnaArticle(int seq);
	void deleteQnaVO(int seq);
	void updateQnaVO(QnaVO qna);
	void updateHit(int seq);
	ArrayList<QnaVO> selectTagVO(Map<String, Object> map);
	
	int selectCount();
	int selectTagCount(String tags);
	
	ArrayList<CommentVO> getCmtBoards(int pc_seq);
	void insertCmtVO(CommentVO cmt);
	void deleteCmtVO(int c_seq);
}
