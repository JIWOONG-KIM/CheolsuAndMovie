package com.kitri.cnm.qnaboard;

public class TagVO {
	private String tags;
	private String tags_name;

	TagVO() {
	}

	public TagVO(String tags, String tags_name) {
		super();
		this.tags = tags;
		this.tags_name = tags_name;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getTags_name() {
		return tags_name;
	}

	public void setTags_name(String tags_name) {
		this.tags_name = tags_name;
	}

	@Override
	public String toString() {
		return "TagVO [tags=" + tags + ", tags_name=" + tags_name + "]";
	}

}
