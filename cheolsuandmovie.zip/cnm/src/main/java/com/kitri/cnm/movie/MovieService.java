package com.kitri.cnm.movie;

import java.util.List;

public interface MovieService {
	void insertMyMovie(MovieVO movie);
	int checkList(MovieVO movie);
	void updatetMyMovie(MovieVO mov);
	public List<String> getMembers(String id);
	List<MovieVO> getList(String id);
	void updateRating(MovieVO m);
	void delMyMovie(int seq);
}
