package com.kitri.cnm.member;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;


@Component("memService")
public class MemberServiceImpl implements MemberService {
	@Resource(name = "sqlSession")
	private SqlSession sqlSession;
	private MemberMapper memberMapper;

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public void addMember(MemberVO m) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		memberMapper.join(m);
	}

	@Override
	public MemberVO editMemberform(String id) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		return memberMapper.editmemberform(id);
	}
	
	@Override
	public void editMember(MemberVO m) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		memberMapper.editmember(m);
	}
	
	@Override
	public MemberVO getMember(String id) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		return memberMapper.idcheck(id);
	}

	@Override
	public List<FriendVO> searchid(String id) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		return memberMapper.friendlist(id);
	}

	@Override
	public void reqfriend(FriendVO f) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		memberMapper.reqfriend(f);
	}

	@Override
	public List<String> friendreqlist(String id) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		return memberMapper.friendreqlist(id);
	}

	@Override
	public List<String> friendreslist(String id) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		return memberMapper.friendreslist(id);
	}

	@Override
	public void friendpermit(FriendVO f) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		memberMapper.friendpermit(f);
	}

	@Override
	public int listcnt() {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		return memberMapper.listcnt();
	}

	@Override
	public List<MemberVO> memberlist(int currentPage) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		return memberMapper.memberlist(currentPage);
	}

	@Override
	public void frienddel(FriendVO f) {
		// TODO Auto-generated method stub
		memberMapper = sqlSession.getMapper(MemberMapper.class);
		System.out.println(f.getId());
		System.out.println(f.getFr_id());
		memberMapper.frienddel(f);
	}

}
