package com.kitri.cnm.member;

import java.util.List;

public interface MemberMapper {
	void join(MemberVO m);
	
	MemberVO editmemberform(String id);
	
	void editmember(MemberVO m);
	
	MemberVO idcheck(String id);
	
	List<FriendVO> friendlist(String id);
	
	void reqfriend (FriendVO f);
	
	List<String> friendreqlist(String id);
	
	List<String> friendreslist(String id);
	
	void friendpermit(FriendVO f);
	
	int listcnt();
	
	List<MemberVO> memberlist(int currentPage);
	
	void frienddel(FriendVO f);
	
}
